   
   {
  "records": [
    {
      "EmployeeName": "Ram",
      "Age": "25",
      "Employeeid": "1234",
      "Salary": "Analyst"
    },
     {
      "EmployeeName": "Varun",
      "Age": "27",
      "Employeeid": "1235",
      "Salary": "Sr.Analyst"
    },
     {
      "EmployeeName": "Arun",
      "Age": "25",
      "Employeeid": "1236",
      "Salary": "Architect"
    },
     {
      "EmployeeName": "Deepa",
      "Age": "25",
      "Employeeid": "1237",
      "Salary": "Tester"
    },
     {
      "EmployeeName": "Anu",
      "Age": "25",
      "Employeeid": "1238",
      "Salary": "Tester"
    }
  ]
}

